package repository;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicoRepository extends JpaRepository<Medico, Long> {}