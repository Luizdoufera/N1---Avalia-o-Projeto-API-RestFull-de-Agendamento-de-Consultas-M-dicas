package com.senai.Luiz.Fernando.consultasmedicas;

public class ConsultasMedicasApplication {

}
