package com.senai.Luiz.Fernando.consultasmedicas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Consulta;

public interface ConsultaRepository extends JpaRepository<Consulta, Long> {}
