package com.senai.Luiz.Fernando.consultasmedicas.service;

import org.springframework.stereotype.Service;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Consulta;
import com.senai.Luiz.Fernando.consultasmedicas.repository.ConsultaRepository;

import java.util.List;


@Service
public class ConsultaService {
    private final ConsultaRepository repository;

    public ConsultaService(ConsultaRepository repository) {
        this.repository = repository;
    }

    public List<Consulta> listarTodas() { return repository.findAll(); }
    public Consulta salvar(Consulta consulta) { return repository.save(consulta); }
}
