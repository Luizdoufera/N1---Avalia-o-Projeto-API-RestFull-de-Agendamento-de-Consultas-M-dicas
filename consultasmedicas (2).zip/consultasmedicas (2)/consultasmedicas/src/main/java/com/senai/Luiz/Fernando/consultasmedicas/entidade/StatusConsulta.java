package com.senai.Luiz.Fernando.consultasmedicas.entidade;

public enum StatusConsulta {
    AGENDADA, CANCELADA, REALIZADA
}
