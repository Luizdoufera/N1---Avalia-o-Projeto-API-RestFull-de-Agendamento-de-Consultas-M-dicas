package com.senai.Luiz.Fernando.consultasmedicas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Medico;

public interface MedicoRepository extends JpaRepository<Medico, Long> {}