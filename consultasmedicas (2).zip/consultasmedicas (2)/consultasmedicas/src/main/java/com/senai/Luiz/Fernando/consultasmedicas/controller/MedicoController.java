package com.senai.Luiz.Fernando.consultasmedicas.controller;

import org.springframework.web.bind.annotation.*;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Medico;
import com.senai.Luiz.Fernando.consultasmedicas.service.MedicoService;

import java.util.List;

@RestController
@RequestMapping("/medicos")
public class MedicoController {
    private final MedicoService service;

    public MedicoController(MedicoService service) { this.service = service; }

    @GetMapping
    public List<Medico> listarTodos() { return service.listarTodos(); }

    @PostMapping
    public Medico salvar(@RequestBody Medico medico) { return service.salvar(medico); }
}
