package com.senai.Luiz.Fernando.consultasmedicas.service;

import org.springframework.stereotype.Service;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Paciente;
import com.senai.Luiz.Fernando.consultasmedicas.repository.PacienteRepository;

import java.util.List;

@Service
public class PacienteService {
    private final PacienteRepository repository;

    public PacienteService(PacienteRepository repository) {
        this.repository = repository;
    }

    public List<Paciente> listarTodos() { return repository.findAll(); }
    public Paciente salvar(Paciente paciente) { return repository.save(paciente); }
}