package com.senai.Luiz.Fernando.consultasmedicas.controller;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.*;
import com.senai.Luiz.Fernando.consultasmedicas.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/consultas")
@Tag(name = "Consultas", description = "Gerenciamento de Consultas Médicas")
public class ConsultaController {

    private final ConsultaService service;

    public ConsultaController(ConsultaService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Listar todas as consultas", description = "Retorna uma lista de consultas agendadas")
    public List<Consulta> listarTodas() {
        return service.listarTodas();
    }

    @PostMapping
    @Operation(summary = "Agendar uma nova consulta", description = "Cadastra uma nova consulta no sistema")
    public Consulta agendar(@RequestBody Consulta consulta) {
        return service.salvar(consulta);
    }
}