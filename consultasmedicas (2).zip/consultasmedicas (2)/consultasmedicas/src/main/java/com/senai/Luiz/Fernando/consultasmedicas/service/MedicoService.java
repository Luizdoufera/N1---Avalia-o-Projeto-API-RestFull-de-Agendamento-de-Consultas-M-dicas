package com.senai.Luiz.Fernando.consultasmedicas.service;

import org.springframework.stereotype.Service;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Medico;
import com.senai.Luiz.Fernando.consultasmedicas.repository.MedicoRepository;

import java.util.List;

@Service
public class MedicoService {
    private final MedicoRepository repository;

    public MedicoService(MedicoRepository repository) {
        this.repository = repository;
    }

    public List<Medico> listarTodos() { return repository.findAll(); }
    public Medico salvar(Medico medico) { return repository.save(medico); }
}
