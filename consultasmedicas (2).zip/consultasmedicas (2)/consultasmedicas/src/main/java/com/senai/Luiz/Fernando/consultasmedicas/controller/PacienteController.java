package com.senai.Luiz.Fernando.consultasmedicas.controller;

import org.springframework.web.bind.annotation.*;

import com.senai.Luiz.Fernando.consultasmedicas.entidade.Paciente;
import com.senai.Luiz.Fernando.consultasmedicas.service.PacienteService;

import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {
    private final PacienteService service;

    public PacienteController(PacienteService service) { this.service = service; }

    @GetMapping
    public List<Paciente> listarTodos() { return service.listarTodos(); }

    @PostMapping
    public Paciente salvar(@RequestBody Paciente paciente) { return service.salvar(paciente); }
}