package com.senai.Luiz.Fernando.consultasmedicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultasmedicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
